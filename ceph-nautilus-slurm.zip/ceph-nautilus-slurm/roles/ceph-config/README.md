# Ansible role: ceph-config

Documentation is available at http://docs.ceph.com/ceph-ansible/.
